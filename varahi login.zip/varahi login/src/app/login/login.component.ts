import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, RequiredValidator, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  jay:any;
  submit=false;

  constructor( private formbuilder:FormBuilder,private route:Router) { }

  ngOnInit(): void {
    this.jay = this.formbuilder.group({
      email:new FormControl('',[Validators.required]),
      password:new FormControl('',[Validators.required])
    })
  }
  get go(){
    return this.jay.Controls
  }
  Submit(){
    
    this.submit=true;
   if(this.jay.invalid){
      return
   }
    
    if(this.go.email.value=="admin@gmail.com" && this.go.Password.value=="admin"){
      this.route.navigate(['/product']);
    }
    else{
     alert("Please Enter The valid User name And Password")
    }
  }
  }


